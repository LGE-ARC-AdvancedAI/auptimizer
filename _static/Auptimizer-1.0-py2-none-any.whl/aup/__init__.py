"""
Copyright (c) 2018 LG Electronics Inc.
SPDX-License-Identifier: BSD-3-Clause
"""
from .EE.Experiment import Experiment
from .aup import BasicConfig
from .aup import print_result

__version__ = "1.0"
