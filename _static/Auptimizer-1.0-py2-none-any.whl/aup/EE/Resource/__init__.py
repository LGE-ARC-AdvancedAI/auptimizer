"""
Copyright (c) 2018 LG Electronics Inc.
SPDX-License-Identifier: BSD-3-Clause
"""
from .AbstractResourceManager import get_resource_manager

