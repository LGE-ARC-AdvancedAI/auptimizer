"""
Copyright (c) 2018 LG Electronics Inc.
SPDX-License-Identifier: BSD-3-Clause
"""