"""
Copyright (c) 2018 LG Electronics Inc.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from .EE.Experiment import Experiment
from .aup import BasicConfig
from .aup import print_result

__version__ = "1.0"
